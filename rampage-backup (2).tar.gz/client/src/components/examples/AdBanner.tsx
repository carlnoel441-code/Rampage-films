import AdBanner from '../AdBanner'

export default function AdBannerExample() {
  return (
    <div className="bg-background py-8">
      <AdBanner />
    </div>
  )
}
